﻿using System;


[Serializable]
public enum SceneIndexEnum
{
    StartMenu,
    MainGame,
    StartingSideRoom,
    GameOver,
    Win,
    Shop,
    Journal,
}