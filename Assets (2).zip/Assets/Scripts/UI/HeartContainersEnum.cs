﻿using System;

[Serializable]
public enum HeartContainersEnum
{
    Empty,
    Half,
    Full
}