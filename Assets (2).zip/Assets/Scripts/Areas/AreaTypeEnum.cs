﻿using System;

namespace Helper
{
    [Serializable]
    public enum AreaTypeEnum
    {
        Error,
        Shore,
        Inland,
        Journal,
    }
}