﻿using Pool;

public class RupeePool : MonoPool<PoolableRupee>
{
}