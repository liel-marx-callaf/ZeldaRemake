using System;
using UnityEngine;

[Serializable]
public enum ItemsEnum 
{
    Heart,
    Rupee,
}
