using Pool;


public class SmokePool : MonoPool<Smoke>
{
}
