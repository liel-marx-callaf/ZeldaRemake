using Pool;
using UnityEngine;

public class TektitePool : MonoPool<PoolableTektite>
{
}
