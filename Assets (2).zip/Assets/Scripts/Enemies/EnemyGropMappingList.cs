﻿using System;
using System.Collections.Generic;

[Serializable]
public class EnemyGroupMappingList
{
    public EnemyGroupEnum enemyGroup;
    public List<EnemyTypeEnum> enemyTypes;
}