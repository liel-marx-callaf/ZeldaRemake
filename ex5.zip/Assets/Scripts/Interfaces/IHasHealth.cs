namespace Interfaces
{
    public interface IHasHealth 
    {
        public void TakeDamage(int damage);
        // private void Die()
    }
}
