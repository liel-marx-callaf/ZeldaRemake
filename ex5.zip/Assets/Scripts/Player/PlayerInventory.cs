﻿using UnityEngine;

namespace Player
{
    public class PlayerInventory : MonoBehaviour
    {
        
    }
}