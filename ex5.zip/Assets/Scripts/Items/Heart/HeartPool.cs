using Pool;

public class HeartPool : MonoPool<PoolableHeart>
{
}
