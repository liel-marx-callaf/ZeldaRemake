using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;
using IPoolable = Pool.IPoolable;

public class TektiteMovement : MonoBehaviour, IPoolable
{
    private static readonly int Jump1 = Animator.StringToHash("Jump");
    private static readonly int Idle = Animator.StringToHash("Idle");
    private static readonly int Load = Animator.StringToHash("Load");

    [Header("Borders (Room Bounds)")]
    [SerializeField] private Vector2 topLeftBorder;
    [SerializeField] private Vector2 bottomRightBorder;
    [SerializeField] private float edgeBuffer = 1f;

    [Header("Timing")]
    [SerializeField, Range(0f, 30f)] private float maxWaitBeforeSpawn = 9f;
    [SerializeField, Range(0f, 10f)] private float maxLoadDuration = 2f;
    [SerializeField, Range(0f, 10f)] private float maxIdleDuration = 2f;
    [SerializeField, Range(0f, 10f)] private float maxJumpInterval = 4f;

    [Header("Jump Settings")]
    [SerializeField, Range(1f, 12f)] private float jumpRange = 4f;
    [SerializeField, Range(0.01f, 5f)] private float jumpDuration = 1f;
    [Tooltip("Extra vertical arc height for the jump animation.")]
    [SerializeField] private float arcHeight = 1.5f;

    private Animator _animator;
    private bool _isDead;
    private bool _isJumping;
    private Vector3 _startPosition;
    private Vector3 _currentPosition;

    private void OnEnable()
    {
        _animator = GetComponent<Animator>();

        _startPosition = transform.position;
        _currentPosition = _startPosition;

        // Optionally freeze the animator until "spawn delay" is over.
        _animator.speed = 0f;

        // Start the behavior loop
        StartCoroutine(MovementCoroutine());
    }

    private IEnumerator MovementCoroutine()
    {
        // _startPosition = transform.position;
        // _currentPosition = _startPosition;
        // 1) Optional “WaitBeforeSpawn”
        float spawnDelay = Random.Range(0f, maxWaitBeforeSpawn);
        yield return new WaitForSeconds(spawnDelay);

        // Now allow animations to play normally
        _animator.speed = 1f;

        while (!_isDead)
        {
            // --- LOAD Phase ---
            if (!IsInAnimationState("TektiteLoad"))
                _animator.SetTrigger(Load);

            float loadTime = Random.Range(0f, maxLoadDuration);
            yield return new WaitForSeconds(loadTime);

            // --- IDLE Phase (20% chance or your own condition) ---
            if (Random.value < 0.2f)
            {
                if (!IsInAnimationState("TektiteIdle"))
                    _animator.SetTrigger(Idle);

                float idleTime = Random.Range(0f, maxIdleDuration);
                yield return new WaitForSeconds(idleTime);
            }

            // --- JUMP Phase ---
            // Wait random time up to maxJumpInterval before jumping
            float waitBeforeJump = Random.Range(0f, maxJumpInterval);
            yield return new WaitForSeconds(waitBeforeJump);

            // Now actually do the jump
            StartCoroutine(JumpArcCoroutine());
            
            // Wait until the jump finishes before repeating the loop
            while (_isJumping && !_isDead)
            {
                yield return null;
            }
        }
    }

    private IEnumerator JumpArcCoroutine()
    {
        _isJumping = true;

        // Trigger the Jump animation
        _animator.SetTrigger(Jump1);

        // 1) Calculate random target within jumpRange
        float randX = Random.Range(-jumpRange, jumpRange);
        float randY = Random.Range(-jumpRange, jumpRange);

        Vector3 targetPos = _currentPosition + new Vector3(randX, randY, 0f);

        // 2) Clamp target to stay in room
        float clampedX = Mathf.Clamp(targetPos.x, topLeftBorder.x + edgeBuffer, bottomRightBorder.x - edgeBuffer);
        float clampedY = Mathf.Clamp(targetPos.y, bottomRightBorder.y + edgeBuffer, topLeftBorder.y - edgeBuffer);
        targetPos = new Vector3(clampedX, clampedY, 0f);

        // 3) Interpolate from _currentPosition to targetPos with a parabolic arc
        float elapsed = 0f;
        Vector3 startPos = _currentPosition;

        while (elapsed < jumpDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / jumpDuration);

            // Horizontal interpolation
            float x = Mathf.Lerp(startPos.x, targetPos.x, t);

            // Simple parabolic arc for y:
            //   y = lerp(startY, targetY, t) + arc offset
            float baseY = Mathf.Lerp(startPos.y, targetPos.y, t);

            // Create a "peak" in the middle
            // e.g. a parabola offset = (1 - (2t - 1)^2) = 4t(1 - t), scaled by arcHeight
            float arcOffset = (1f - Mathf.Pow(2f*t - 1f, 2f)) * arcHeight;
            float y = baseY + arcOffset;

            // Update position
            transform.position = new Vector3(x, y, 0f);

            yield return null;
        }

        // At the end of the jump, land exactly at target
        transform.position = targetPos;
        _currentPosition = targetPos;

        // Switch to Idle after landing
        if (!_isDead)
            _animator.SetTrigger(Idle);

        _isJumping = false;
    }

    private bool IsInAnimationState(string stateName)
    {
        AnimatorStateInfo stateInfo = _animator.GetCurrentAnimatorStateInfo(0);
        return stateInfo.IsName(stateName);
    }

    // Called externally if the Tektite dies
    public void OnDeath()
    {
        _isDead = true;
        // Stop any jump coroutines if you like
        StopAllCoroutines();
        // Possibly switch to a Death animation or disable movement
    }

    // IPoolable requirement
    public void Reset()
    {
        _isDead = false;
        _isJumping = false;
        // Potentially reset the animator or position
    }

    public void SetTopLeftBorder(Vector2 newTopLeftBorder)
    {
        topLeftBorder = newTopLeftBorder;
    }

    public void SetBottomRightBorder(Vector2 newBottomRightBorder)
    {
        bottomRightBorder = newBottomRightBorder;
    }
}
